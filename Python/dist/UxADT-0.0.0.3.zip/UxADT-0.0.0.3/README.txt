
  uxadt.py

   A library that supports a universal, cross-platform embedded
   representation for algebraic data type (ADT) values, and a
   programming abstraction for operations (such as pattern
   matching) on algebraic data type values.

   Web:     uxadt.org
   Version: 0.0.0.3
